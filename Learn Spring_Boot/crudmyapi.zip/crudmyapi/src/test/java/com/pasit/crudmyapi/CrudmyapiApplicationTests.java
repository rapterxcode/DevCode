package com.pasit.crudmyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudmyapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
