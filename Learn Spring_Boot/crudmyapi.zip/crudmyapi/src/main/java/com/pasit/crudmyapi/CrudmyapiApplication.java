package com.pasit.crudmyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudmyapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudmyapiApplication.class, args);
	}

}
